Below is an overview for each html page and their output

index.html: 
This is the home page where it overview the month's specials and lists contact information

classic.html:
This page goes over 3 classic desserts with descriptions and images of each one

signature.html:
This page goes over 3 signature desserts with descriptions and images of each one

special-orders.html:
This page gives the user an opportunity to enter in an order that would be sent to the business